<script>
 
</script>

<style>
  .header {
    background-color: #f1f1f1;
    padding: 2px;
  }
  /* Global */
  body,
  input {
    color: #333;
    font-family: Open Sans, sans-serif;
    margin: 0;
  }
  article {
    border: 0;
    margin: auto;
    overflow: hidden;
    position: relative;
    min-height: 600px;
    width: 600px;
  }
  #content {
    position: absolute;
    top: 0px;
    left: 0px;
    width: 2416px;
  }
  section {
    display: inline-table;
    margin: 0;
    width: 600px;
  }
  p {
    line-height: 1.75em;
  }
  input {
    font-weight: 300;
    -webkit-appearance: none;
  }
  input:focus {
    outline: 0;
  }

  /* Navigation */
  nav ul {
    margin: 0;
    padding: 0;
  }
  nav ul li {
    display: inline-block;
    font-size: 14pt;
    font-weight: 300;
    line-height: 42px;
  }
  nav ul li a {
    color: #222;
    display: block;
    padding: 0 20px;
    text-decoration: none;
  }
  nav ul li:hover ul li:hover {
    background: #ccc;
  }
  .current {
    background: #222;
  }
  .current a {
    color: #fff;
  }

  /* Mobile 响应式布局*/
  @media screen and (max-width: 768px) {
    nav {
      display: table;
      table-layout: fixed;
      margin: auto;
      text-align: center;
      width: 90%;
    }
    nav ul {
      display: table-row;
    }
    nav ul li {
      border-top: 1px solid #222;
      border-bottom: 1px solid #222;
      border-left: 1px solid #222;
      display: table-cell;
      font-size: 10pt;
      margin: 0;
      padding: 0;
      line-height: 30px;
      text-align: center;
    }
    nav ul li a {
      color: #222;
      padding: 0;
      width: 100%;
    }
    nav ul li:first-of-type {
      border-radius: 10px 0 0 10px;
    }
    nav ul li:last-of-type {
      border-radius: 0 10px 10px 0;
      border-right: 1px solid #222;
    }
    .caret {
      display: none;
    }
    article {
      width: 300px;
    }
    #content {
      width: 1208px;
    }
    section {
      width: 298px;
    }
  }
</style>

<main>
  <div class="header">
    <div id="logo-text">
      <h1>Unbox AI</h1>
    </div>

    <div id="topnav">
      <nav>
        <ul>
          <li class="current">
            <a href="#start">Start</a>
          </li>
          <li>
            <a href="#cnn">CNN</a>
          </li>
          <li>
            <a href="#rnn">RNN</a>
          </li>
          <li>
            <a href="#random forests">Random Forests</a>
          </li>
        </ul>
      </nav>
    </div>
  </div>

  <article>
    <div id="content">
      <section>
        <h1>An Introduction to Neural Networks</h1>
        <p>
          <strong>
            。。。
          </strong>
        </p>
        <p>
         。。。
        </p>
      </section>
      <section>
        <h1>Portfolio</h1>
        <p>Portfolio content</p>
      </section>
      <section>
        <h1>About</h1>
        <p>About content</p>
      </section>
      <section>
        <h1>Contact</h1>
        <p>Contact details</p>
      </section>
    </div>
  </article>
</main>
