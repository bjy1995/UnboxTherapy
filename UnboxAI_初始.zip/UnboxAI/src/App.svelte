<script>
	 import Header from './Header.svelte';
</script>


<style>
</style>

<div id="app-page">
	<Header />
</div>

